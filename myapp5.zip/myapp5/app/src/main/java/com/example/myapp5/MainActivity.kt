// MainActivity.kt
package com.example.myapp5

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.mainapp.TodoListActivity
import com.example.myapp6.CalculatorActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonCalculator: Button = findViewById(R.id.buttonCalculator)
        val buttonTodoList: Button = findViewById(R.id.buttonTodoList)

        buttonCalculator.setOnClickListener {
            val intent = Intent(this, CalculatorActivity::class.java)
            intent.putExtra("initValue", "0")
            startActivity(intent)
        }

        buttonTodoList.setOnClickListener {
            val intent = Intent(this, TodoListActivity::class.java)
            intent.putExtra("welcomeMessage", "Welcome to Todo List")
            startActivity(intent)
        }
    }
}
