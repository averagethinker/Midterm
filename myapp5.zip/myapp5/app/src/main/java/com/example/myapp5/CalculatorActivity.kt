// CalculatorActivity.kt
package com.example.myapp6

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.myapp5.R

class CalculatorActivity : AppCompatActivity() {

    private lateinit var tvResult: TextView
    private var firstNumber: String = ""
    private var secondNumber: String = ""
    private var operation: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculator)

        tvResult = findViewById(R.id.tvResult)
        val initialValue = intent.getStringExtra("initValue") ?: "0"
        tvResult.text = initialValue

        val buttons = listOf<Button>(
            findViewById(R.id.btn0), findViewById(R.id.btn1), findViewById(R.id.btn2),
            findViewById(R.id.btn3), findViewById(R.id.btn4), findViewById(R.id.btn5),
            findViewById(R.id.btn6), findViewById(R.id.btn7), findViewById(R.id.btn8),
            findViewById(R.id.btn9), findViewById(R.id.btnAdd), findViewById(R.id.btnSubtract),
            findViewById(R.id.btnMultiply), findViewById(R.id.btnDivide), findViewById(R.id.btnClear),
            findViewById(R.id.btnEquals)
        )

        for (button in buttons) {
            button.setOnClickListener { onButtonClick(it as Button) }
        }
    }

    private fun onButtonClick(button: Button) {
        val buttonText = button.text.toString()

        when (buttonText) {
            "C" -> {
                firstNumber = ""
                secondNumber = ""
                operation = ""
                tvResult.text = "0"
            }
            "+", "-", "*", "/" -> {
                operation = buttonText
                tvResult.text = "$firstNumber $operation"
            }
            "=" -> {
                val result = performCalculation()
                tvResult.text = result.toString()
                firstNumber = result.toString()
                secondNumber = ""
                operation = ""
            }
            else -> {
                if (operation.isEmpty()) {
                    firstNumber += buttonText
                    tvResult.text = firstNumber
                } else {
                    secondNumber += buttonText
                    tvResult.text = "$firstNumber $operation $secondNumber"
                }
            }
        }
    }

    private fun performCalculation(): Double {
        val num1 = firstNumber.toDoubleOrNull() ?: 0.0
        val num2 = secondNumber.toDoubleOrNull() ?: 0.0

        return when (operation) {
            "+" -> num1 + num2
            "-" -> num1 - num2
            "*" -> num1 * num2
            "/" -> if (num2 != 0.0) num1 / num2 else Double.NaN
            else -> 0.0
        }
    }
}
